<?php
/**
 * The template for displaying the footer
 */

?>

<footer id="footer" role="contentinfo" >
    <p>Copyright <?php echo date("Y"); ?> <?php bloginfo( 'title' ); ?> | Powered by <a href="http://www.saeon.ac.za/" target="_blank">SAEON</a></p>
</footer>

<?php wp_footer(); ?>

</body>
</html>